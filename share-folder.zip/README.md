### SEPIA Speech-To-Text Server - Shared folder

This zip file contains the content of the 'share' folder used for the Docker version of the SEPIA STT-Server.
The 'share' folder can be used to add a custom config, models, language model training or capture recordings.  
  
For more info see the Docker part of the STT-Server description (it's in the README).

